import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.database import Base, get_db
from app.main import app
from app.core.deps import get_current_user_optional, get_current_user
from app.core.identity.models import User

sync_engine = create_engine(
    "sqlite:///:memory:",
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
SyncTestingSessionLocal = sessionmaker(
    autocommit=False, autoflush=False, bind=sync_engine
)


@pytest.fixture
def sync_db():
    Base.metadata.create_all(bind=sync_engine)
    db = SyncTestingSessionLocal()
    try:
        yield db
    finally:
        db.close()
        Base.metadata.drop_all(bind=sync_engine)


@pytest_asyncio.fixture
async def client(sync_db):
    def _override_get_db():
        yield sync_db

    dummy_user = User(
        id=1,
        username="admin",
        email="admin@example.com",
        is_active=True,
        is_superuser=True,
        business_id=1,
    )
    dummy_user.get_all_permission_codes = lambda: {
        "hrm:employees:view", "hrm:employees:create", "hrm:employees:update", "hrm:employees:delete",
        "hrm:compensation:view", "hrm:compensation:create", "hrm:compensation:update", "hrm:compensation:delete",
        "hrm:holidays:view", "hrm:holidays:create", "hrm:holidays:update", "hrm:holidays:delete",
        "hrm:payroll_periods:view", "hrm:payroll_periods:create", "hrm:payroll_periods:update", "hrm:payroll_periods:delete",
        "hrm:payroll_records:view", "hrm:payroll_records:create", "hrm:payroll_records:update", "hrm:payroll_records:delete",
        "hrm:payroll_settings:view", "hrm:payroll_settings:update", "hrm:attendance:create",
    }
    dummy_user.has_permission = lambda code: True

    app.dependency_overrides[get_db] = _override_get_db
    app.dependency_overrides[get_current_user_optional] = lambda request=None: dummy_user
    app.dependency_overrides[get_current_user] = lambda request=None: dummy_user
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac
    app.dependency_overrides.clear()


@pytest.mark.asyncio
async def test_holiday_crud(client: AsyncClient):
    # Create holiday
    payload = {
        "business_id": 1,
        "name": "Independence Day",
        "holiday_type": "public",
        "start_date": "2025-03-26",
        "end_date": "2025-03-26",
        "is_paid": True,
        "description": "National Holiday",
    }
    response = await client.post("/payroll/holidays", json=payload)
    assert response.status_code == 201
    holiday_id = response.json()["id"]

    # List holidays
    response = await client.get("/payroll/holidays?business_id=1")
    assert response.status_code == 200
    assert len(response.json()) == 1

    # Get holiday
    response = await client.get(f"/payroll/holidays/{holiday_id}")
    assert response.status_code == 200
    assert response.json()["name"] == "Independence Day"

    # Update holiday
    response = await client.put(
        f"/payroll/holidays/{holiday_id}",
        json={"name": "Independence Day (Observed)"},
    )
    assert response.status_code == 200
    assert response.json()["name"] == "Independence Day (Observed)"

    # Delete holiday
    response = await client.delete(f"/payroll/holidays/{holiday_id}")
    assert response.status_code == 204


@pytest.mark.asyncio
async def test_payroll_period_crud(client: AsyncClient):
    # Create period
    payload = {
        "business_id": 1,
        "name": "January 2025",
        "start_date": "2025-01-01",
        "end_date": "2025-01-31",
        "status": "draft",
        "payment_date": "2025-01-31",
        "notes": "Jan run",
    }
    response = await client.post("/payroll/periods", json=payload)
    assert response.status_code == 201
    period_id = response.json()["id"]

    # List periods
    response = await client.get("/payroll/periods?business_id=1")
    assert response.status_code == 200
    assert len(response.json()) == 1

    # Update period status to processing
    response = await client.put(
        f"/payroll/periods/{period_id}", json={"status": "processing"}
    )
    assert response.status_code == 200
    assert response.json()["status"] == "processing"

    # Lock period
    response = await client.put(
        f"/payroll/periods/{period_id}", json={"status": "locked"}
    )
    assert response.status_code == 200
    assert response.json()["is_locked"] is True

    # Attempt to delete locked period -> 400
    response = await client.delete(f"/payroll/periods/{period_id}")
    assert response.status_code == 400

    # Unlock and delete
    await client.put(f"/payroll/periods/{period_id}", json={"status": "draft"})
    response = await client.delete(f"/payroll/periods/{period_id}")
    assert response.status_code == 204


@pytest.mark.asyncio
async def test_payroll_record_crud(client: AsyncClient, sync_db):
    # Setup employee and period via client
    emp_res = await client.post(
        "/employees",
        json={
            "first_name": "Jane",
            "last_name": "Doe",
            "employee_id": "EMP-999",
            "work_email": "jane.doe@example.com",
            "phone": "+1234567890",
            "business_id": 1,
        },
    )
    assert emp_res.status_code == 201
    emp_id = emp_res.json()["id"]

    period_res = await client.post(
        "/payroll/periods",
        json={
            "business_id": 1,
            "name": "February 2025",
            "start_date": "2025-02-01",
            "end_date": "2025-02-28",
            "status": "draft",
        },
    )
    assert period_res.status_code == 201
    period_id = period_res.json()["id"]

    # Create payslip record
    payload = {
        "business_id": 1,
        "period_id": period_id,
        "employee_id": emp_id,
        "working_days": 20,
        "present_days": 20,
        "basic_salary": 5000.0,
        "house_rent": 1000.0,
        "transport_allowance": 300.0,
        "medical_allowance": 200.0,
        "food_allowance": 100.0,
        "other_allowance": 50.0,
        "overtime_pay": 150.0,
        "bonus": 200.0,
        "tax": 500.0,
        "provident_fund": 300.0,
        "unpaid_leave_deduction": 0.0,
        "loan_installment": 100.0,
        "other_deduction": 50.0,
        "payment_method": "bank_transfer",
        "is_paid": False,
    }
    response = await client.post("/payroll/records", json=payload)
    assert response.status_code == 201
    rec = response.json()
    record_id = rec["id"]

    # Verify gross, total deduction, and net salary calculations
    # gross = 5000 + 1000 + 300 + 200 + 100 + 50 + 150 + 200 = 7000.0
    # deductions = 500 + 300 + 0 + 100 + 50 = 950.0
    # net = 7000 - 950 = 6050.0
    assert rec["gross_salary"] == 7000.0
    assert rec["total_deduction"] == 950.0
    assert rec["net_salary"] == 6050.0

    # Get record
    response = await client.get(f"/payroll/records/{record_id}")
    assert response.status_code == 200

    # Update record
    response = await client.put(
        f"/payroll/records/{record_id}", json={"is_paid": True, "bonus": 500.0}
    )
    assert response.status_code == 200
    rec_updated = response.json()
    assert rec_updated["is_paid"] is True
    # gross updated = 7300.0, net = 6350.0
    assert rec_updated["gross_salary"] == 7300.0
    assert rec_updated["net_salary"] == 6350.0

    # Delete record
    response = await client.delete(f"/payroll/records/{record_id}")
    assert response.status_code == 204


@pytest.mark.asyncio
async def test_bulk_payroll_generation_with_settings(client: AsyncClient):
    # 1. Create employee
    emp_res = await client.post(
        "/employees",
        json={
            "first_name": "Charlie",
            "last_name": "Brown",
            "employee_id": "EMP-300",
            "work_email": "charlie.brown@example.com",
            "phone": "+1234567895",
            "business_id": 1,
        },
    )
    assert emp_res.status_code == 201
    emp_id = emp_res.json()["id"]

    # 2. Set employee salary setup
    salary_payload = {
        "business_id": 1,
        "employee_id": emp_id,
        "basic_salary": 3100.0,
        "house_rent": 500.0,
        "medical_allowance": 200.0,
        "transport_allowance": 100.0,
        "food_allowance": 0.0,
        "other_allowance": 0.0,
        "tax": 100.0,
        "provident_fund": 50.0,
        "other_deduction": 0.0,
        "currency": "USD",
        "effective_from": "2025-01-01",
    }
    sal_res = await client.post("/compensation/salaries", json=salary_payload)
    assert sal_res.status_code == 201

    # 3. Create Payroll Period (March 2025: 31 days)
    period_res = await client.post(
        "/payroll/periods",
        json={
            "business_id": 1,
            "name": "March 2025",
            "start_date": "2025-03-01",
            "end_date": "2025-03-31",
            "status": "draft",
        },
    )
    assert period_res.status_code == 201
    period_id = period_res.json()["id"]

    # 4. Log 10 present days with 2 overtime hours each
    for day in range(1, 11):
        att_d = f"2025-03-{day:02d}"
        att_res = await client.post(
            "/attendance",
            json={
                "business_id": 1,
                "employee_id": emp_id,
                "date": att_d,
                "status": "present",
                "work_hours": 10.0,
                "overtime_hours": 2.0,
            },
        )
        assert att_res.status_code == 201

    # 5. Generate Payroll
    gen_res = await client.post(f"/payroll/periods/{period_id}/generate")
    assert gen_res.status_code == 200
    records = gen_res.json()
    assert len(records) >= 1

    emp_rec = next(r for r in records if r["employee_id"] == emp_id)
    assert emp_rec["working_days"] == 31
    assert emp_rec["present_days"] == 10
    assert emp_rec["overtime_hours"] == 20.0
    assert emp_rec["overtime_pay"] > 0
    assert emp_rec["unpaid_leave_deduction"] > 0
