"""
cPanel / Phusion Passenger entry point.

Passenger speaks WSGI, while FastAPI is ASGI. `a2wsgi` bridges the two.
Passenger never sends ASGI "lifespan" events, so the FastAPI
`@app.on_event("startup")` handlers (table creation + admin/permission
seeding) are executed manually here, once per worker process.
"""
import asyncio
import logging
import os
import sys

# --- Make the project root the CWD and importable -------------------------
# app/main.py uses relative paths ("app/static", ".env"), so CWD must be here.
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE_DIR)
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

# --- Logging to a file you can read from cPanel File Manager --------------
logging.basicConfig(
    filename=os.path.join(BASE_DIR, "passenger_app.log"),
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("passenger_wsgi")

from a2wsgi import ASGIMiddleware  # noqa: E402

from app.main import app  # noqa: E402
from app.database import async_engine  # noqa: E402


async def _run_startup_handlers():
    for handler in app.router.on_startup:
        result = handler()
        if asyncio.iscoroutine(result):
            await result
    # Connections created in this temporary loop must not be reused by the
    # request loop that a2wsgi creates (asyncpg is loop-bound).
    await async_engine.dispose()


try:
    asyncio.run(_run_startup_handlers())
    log.info("Startup handlers completed")
except Exception:
    log.exception("Startup handlers failed")

application = ASGIMiddleware(app)
