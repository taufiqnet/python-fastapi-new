import uuid

from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.core.deps import get_current_user_optional, require_permission
from app.core.tenancy.scoping import resolve_business_id
from app.core.tenancy.service import BusinessService
from app.database import get_async_db, get_db
from app.modules.hr_payroll.employees.service import EmployeeService
from app.modules.hr_payroll.leave.models import GenderApplicabilityEnum
from app.modules.hr_payroll.leave.service import (
    LeaveAllocationService,
    LeaveApplicationService,
    LeaveTypeService,
)

router = APIRouter(prefix="", tags=["Leave Views"])
templates = Jinja2Templates(directory="app/templates")

leave_type_service = LeaveTypeService()
leave_allocation_service = LeaveAllocationService()
leave_application_service = LeaveApplicationService()
employee_service = EmployeeService()
business_service = BusinessService()


# --- Leave Type Views ---
@router.get("/leave/types/manage", response_class=HTMLResponse)
async def leave_type_list_page(
    request: Request,
    skip: int = 0,
    limit: int = 500,
    business_id: int | None = None,
    _perm=Depends(require_permission("hrm", "leave_types", "view")),
    db: Session = Depends(get_db),
    async_db=Depends(get_async_db),
):
    current_user = await get_current_user_optional(request, None, async_db)
    resolved_business_id = resolve_business_id(current_user, business_id)

    leave_types = leave_type_service.get_leave_types(
        db, skip=skip, limit=limit, business_id=resolved_business_id
    )
    if current_user and not current_user.is_superuser:
        businesses = [b for b in business_service.list_businesses(db, skip=0, limit=500) if b.id == current_user.business_id]
    else:
        businesses = business_service.list_businesses(db, skip=0, limit=500)
    biz_map = {b.id: b.name_en for b in businesses}

    total_count = len(leave_types)
    active_count = sum(1 for lt in leave_types if getattr(lt, "is_active", True))
    inactive_count = total_count - active_count
    paid_count = sum(1 for lt in leave_types if getattr(lt, "is_paid", True))

    return templates.TemplateResponse(
        request=request,
        name="modules/hr_payroll/leave/leave_type_list.html",
        context={
            "current_user": current_user,
            "leave_types": leave_types,
            "businesses": businesses,
            "biz_map": biz_map,
            "total_count": total_count,
            "active_count": active_count,
            "inactive_count": inactive_count,
            "paid_count": paid_count,
            "active_page": "leave_types",
        },
    )


@router.get("/leave/types/create", response_class=HTMLResponse)
async def leave_type_create_page(
    request: Request,
    _perm=Depends(require_permission("hrm", "leave_types", "create")),
    db: Session = Depends(get_db),
    async_db=Depends(get_async_db),
):
    current_user = await get_current_user_optional(request, None, async_db)
    if current_user and not current_user.is_superuser:
        businesses = [b for b in business_service.list_businesses(db, skip=0, limit=500) if b.id == current_user.business_id]
    else:
        businesses = business_service.list_businesses(db, skip=0, limit=500)

    return templates.TemplateResponse(
        request=request,
        name="modules/hr_payroll/leave/leave_type_form.html",
        context={
            "leave_type": None,
            "is_edit": False,
            "businesses": businesses,
            "gender_options": GenderApplicabilityEnum,
            "active_page": "leave_types",
        },
    )


@router.get("/leave/types/edit/{leave_type_id}", response_class=HTMLResponse)
async def leave_type_edit_page(
    leave_type_id: uuid.UUID,
    request: Request,
    _perm=Depends(require_permission("hrm", "leave_types", "update")),
    db: Session = Depends(get_db),
    async_db=Depends(get_async_db),
):
    current_user = await get_current_user_optional(request, None, async_db)
    leave_type = leave_type_service.get_leave_type(db, leave_type_id, current_user=current_user)

    if current_user and not current_user.is_superuser:
        businesses = [b for b in business_service.list_businesses(db, skip=0, limit=500) if b.id == current_user.business_id]
    else:
        businesses = business_service.list_businesses(db, skip=0, limit=500)

    return templates.TemplateResponse(
        request=request,
        name="modules/hr_payroll/leave/leave_type_form.html",
        context={
            "leave_type": leave_type,
            "is_edit": True,
            "businesses": businesses,
            "gender_options": GenderApplicabilityEnum,
            "active_page": "leave_types",
        },
    )


# --- Leave Allocation Views ---
@router.get("/leave/allocations/manage", response_class=HTMLResponse)
async def leave_allocation_list_page(
    request: Request,
    skip: int = 0,
    limit: int = 500,
    business_id: int | None = None,
    employee_id: uuid.UUID | None = None,
    year: int | None = None,
    _perm=Depends(require_permission("hrm", "leave_allocations", "view")),
    db: Session = Depends(get_db),
    async_db=Depends(get_async_db),
):
    current_user = await get_current_user_optional(request, None, async_db)
    resolved_business_id = resolve_business_id(current_user, business_id)

    allocations = leave_allocation_service.get_allocations(
        db,
        skip=skip,
        limit=limit,
        business_id=resolved_business_id,
        employee_id=employee_id,
        year=year,
    )
    if current_user and not current_user.is_superuser:
        businesses = [b for b in business_service.list_businesses(db, skip=0, limit=500) if b.id == current_user.business_id]
    else:
        businesses = business_service.list_businesses(db, skip=0, limit=500)

    leave_types = leave_type_service.get_leave_types(db, skip=0, limit=500, business_id=resolved_business_id)
    employees = employee_service.get_employees(db, skip=0, limit=500, business_id=resolved_business_id)

    biz_map = {b.id: b.name_en for b in businesses}
    lt_map = {lt.id: lt.name for lt in leave_types}
    emp_map = {e.id: e.full_name for e in employees}

    total_count = len(allocations)
    total_allocated_days = sum(float(a.allocated_days) for a in allocations)
    total_used_days = sum(float(a.used_days) for a in allocations)
    total_remaining_days = sum(a.remaining_days for a in allocations)

    return templates.TemplateResponse(
        request=request,
        name="modules/hr_payroll/leave/leave_allocation_list.html",
        context={
            "current_user": current_user,
            "allocations": allocations,
            "businesses": businesses,
            "leave_types": leave_types,
            "employees": employees,
            "biz_map": biz_map,
            "lt_map": lt_map,
            "emp_map": emp_map,
            "total_count": total_count,
            "total_allocated_days": total_allocated_days,
            "total_used_days": total_used_days,
            "total_remaining_days": total_remaining_days,
            "active_page": "leave_allocations",
        },
    )


@router.get("/leave/allocations/create", response_class=HTMLResponse)
async def leave_allocation_create_page(
    request: Request,
    _perm=Depends(require_permission("hrm", "leave_allocations", "create")),
    db: Session = Depends(get_db),
    async_db=Depends(get_async_db),
):
    current_user = await get_current_user_optional(request, None, async_db)
    resolved_business_id = resolve_business_id(current_user, None)

    if current_user and not current_user.is_superuser:
        businesses = [b for b in business_service.list_businesses(db, skip=0, limit=500) if b.id == current_user.business_id]
    else:
        businesses = business_service.list_businesses(db, skip=0, limit=500)

    leave_types = leave_type_service.get_leave_types(db, skip=0, limit=500, business_id=resolved_business_id)
    employees = employee_service.get_employees(db, skip=0, limit=500, business_id=resolved_business_id)

    return templates.TemplateResponse(
        request=request,
        name="modules/hr_payroll/leave/leave_allocation_form.html",
        context={
            "allocation": None,
            "is_edit": False,
            "businesses": businesses,
            "leave_types": leave_types,
            "employees": employees,
            "active_page": "leave_allocations",
        },
    )


@router.get("/leave/allocations/edit/{allocation_id}", response_class=HTMLResponse)
async def leave_allocation_edit_page(
    allocation_id: uuid.UUID,
    request: Request,
    _perm=Depends(require_permission("hrm", "leave_allocations", "update")),
    db: Session = Depends(get_db),
    async_db=Depends(get_async_db),
):
    current_user = await get_current_user_optional(request, None, async_db)
    allocation = leave_allocation_service.get_allocation(db, allocation_id, current_user=current_user)

    if current_user and not current_user.is_superuser:
        businesses = [b for b in business_service.list_businesses(db, skip=0, limit=500) if b.id == current_user.business_id]
    else:
        businesses = business_service.list_businesses(db, skip=0, limit=500)

    leave_types = leave_type_service.get_leave_types(db, skip=0, limit=500, business_id=allocation.business_id)
    employees = employee_service.get_employees(db, skip=0, limit=500, business_id=allocation.business_id)

    return templates.TemplateResponse(
        request=request,
        name="modules/hr_payroll/leave/leave_allocation_form.html",
        context={
            "allocation": allocation,
            "is_edit": True,
            "businesses": businesses,
            "leave_types": leave_types,
            "employees": employees,
            "active_page": "leave_allocations",
        },
    )


# --- Leave Application Views ---
@router.get("/leave/applications/manage", response_class=HTMLResponse)
async def leave_application_list_page(
    request: Request,
    skip: int = 0,
    limit: int = 500,
    business_id: int | None = None,
    employee_id: uuid.UUID | None = None,
    status_filter: str | None = None,
    _perm=Depends(require_permission("hrm", "leave_applications", "view")),
    db: Session = Depends(get_db),
    async_db=Depends(get_async_db),
):
    current_user = await get_current_user_optional(request, None, async_db)
    resolved_business_id = resolve_business_id(current_user, business_id)

    applications = leave_application_service.get_applications(
        db,
        skip=skip,
        limit=limit,
        business_id=resolved_business_id,
        employee_id=employee_id,
        status_filter=status_filter,
    )
    if current_user and not current_user.is_superuser:
        businesses = [b for b in business_service.list_businesses(db, skip=0, limit=500) if b.id == current_user.business_id]
    else:
        businesses = business_service.list_businesses(db, skip=0, limit=500)

    leave_types = leave_type_service.get_leave_types(db, skip=0, limit=500, business_id=resolved_business_id)
    employees = employee_service.get_employees(db, skip=0, limit=500, business_id=resolved_business_id)

    biz_map = {b.id: b.name_en for b in businesses}
    lt_map = {lt.id: lt.name for lt in leave_types}
    emp_map = {e.id: e.full_name for e in employees}

    total_count = len(applications)
    pending_count = sum(
        1
        for app in applications
        if getattr(app.status, "value", app.status) == "pending"
    )
    approved_count = sum(
        1
        for app in applications
        if getattr(app.status, "value", app.status) == "approved"
    )
    rejected_count = sum(
        1
        for app in applications
        if getattr(app.status, "value", app.status) == "rejected"
    )

    return templates.TemplateResponse(
        request=request,
        name="modules/hr_payroll/leave/leave_application_list.html",
        context={
            "current_user": current_user,
            "applications": applications,
            "businesses": businesses,
            "leave_types": leave_types,
            "employees": employees,
            "biz_map": biz_map,
            "lt_map": lt_map,
            "emp_map": emp_map,
            "total_count": total_count,
            "pending_count": pending_count,
            "approved_count": approved_count,
            "rejected_count": rejected_count,
            "active_page": "leave_applications",
        },
    )


@router.get("/leave/applications/create", response_class=HTMLResponse)
async def leave_application_create_page(
    request: Request,
    _perm=Depends(require_permission("hrm", "leave_applications", "create")),
    db: Session = Depends(get_db),
    async_db=Depends(get_async_db),
):
    current_user = await get_current_user_optional(request, None, async_db)
    resolved_business_id = resolve_business_id(current_user, None)

    if current_user and not current_user.is_superuser:
        businesses = [b for b in business_service.list_businesses(db, skip=0, limit=500) if b.id == current_user.business_id]
    else:
        businesses = business_service.list_businesses(db, skip=0, limit=500)

    leave_types = leave_type_service.get_leave_types(db, skip=0, limit=500, business_id=resolved_business_id)
    employees = employee_service.get_employees(db, skip=0, limit=500, business_id=resolved_business_id)

    return templates.TemplateResponse(
        request=request,
        name="modules/hr_payroll/leave/leave_application_form.html",
        context={
            "application": None,
            "is_edit": False,
            "businesses": businesses,
            "leave_types": leave_types,
            "employees": employees,
            "active_page": "leave_applications",
        },
    )


@router.get("/leave/applications/edit/{application_id}", response_class=HTMLResponse)
async def leave_application_edit_page(
    application_id: uuid.UUID,
    request: Request,
    _perm=Depends(require_permission("hrm", "leave_applications", "update")),
    db: Session = Depends(get_db),
    async_db=Depends(get_async_db),
):
    current_user = await get_current_user_optional(request, None, async_db)
    application = leave_application_service.get_application(db, application_id, current_user=current_user)

    if current_user and not current_user.is_superuser:
        businesses = [b for b in business_service.list_businesses(db, skip=0, limit=500) if b.id == current_user.business_id]
    else:
        businesses = business_service.list_businesses(db, skip=0, limit=500)

    leave_types = leave_type_service.get_leave_types(db, skip=0, limit=500, business_id=application.business_id)
    employees = employee_service.get_employees(db, skip=0, limit=500, business_id=application.business_id)

    return templates.TemplateResponse(
        request=request,
        name="modules/hr_payroll/leave/leave_application_form.html",
        context={
            "application": application,
            "is_edit": True,
            "businesses": businesses,
            "leave_types": leave_types,
            "employees": employees,
            "active_page": "leave_applications",
        },
    )


@router.get("/leave/applications/detail/{application_id}", response_class=HTMLResponse)
async def leave_application_detail_page(
    application_id: uuid.UUID,
    request: Request,
    _perm=Depends(require_permission("hrm", "leave_applications", "view")),
    db: Session = Depends(get_db),
    async_db=Depends(get_async_db),
):
    current_user = await get_current_user_optional(request, None, async_db)
    application = leave_application_service.get_application(db, application_id, current_user=current_user)
    employees = employee_service.get_employees(db, skip=0, limit=500, business_id=application.business_id)

    return templates.TemplateResponse(
        request=request,
        name="modules/hr_payroll/leave/leave_application_detail.html",
        context={
            "application": application,
            "employees": employees,
            "active_page": "leave_applications",
        },
    )
