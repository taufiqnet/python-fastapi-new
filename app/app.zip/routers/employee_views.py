import uuid

from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.core.deps import get_current_user_optional, require_permission
from app.core.identity.models import User
from app.core.tenancy.scoping import resolve_business_id
from app.core.tenancy.service import BusinessService
from app.database import get_async_db, get_db
from app.modules.hr_payroll.employees.models import (
    EmploymentTypeEnum,
    GenderEnum,
    MaritalStatusEnum,
    WorkArrangementEnum,
)
from app.modules.hr_payroll.employees.service import EmployeeService
from app.modules.hr_payroll.organization.service import (
    DepartmentService,
    JobTitleService,
)

router = APIRouter(prefix="", tags=["Employee Views"])
templates = Jinja2Templates(directory="app/templates")

employee_service = EmployeeService()
department_service = DepartmentService()
job_title_service = JobTitleService()
business_service = BusinessService()


@router.get("/employees/manage", response_class=HTMLResponse)
async def employee_list_page(
    request: Request,
    skip: int = 0,
    limit: int = 10000,
    business_id: int | None = None,
    department_id: uuid.UUID | None = None,
    db: Session = Depends(get_db),
    async_db=Depends(get_async_db),
    current_user: User = Depends(require_permission("hrm", "employees", "view")),
):
    resolved_business_id = resolve_business_id(current_user, business_id)
    employees = employee_service.get_employees(
        db,
        skip=skip,
        limit=limit,
        business_id=resolved_business_id,
        department_id=department_id,
    )
    businesses = business_service.list_businesses(db, skip=0, limit=500)
    departments = department_service.get_departments(db, skip=0, limit=500, business_id=resolved_business_id)
    job_titles = job_title_service.get_job_titles(db, skip=0, limit=500, business_id=resolved_business_id)

    biz_map = {b.id: b.name_en for b in businesses}
    dept_map = {d.id: d.name for d in departments}
    jt_map = {j.id: j.name for j in job_titles}

    if current_user and not current_user.is_superuser:
        businesses = [b for b in businesses if b.id == current_user.business_id]

    total_count = len(employees)
    active_count = sum(1 for e in employees if getattr(e, "is_active", True))
    inactive_count = total_count - active_count
    dept_head_count = sum(
        1 for e in employees if getattr(e, "is_department_head", False)
    )

    return templates.TemplateResponse(
        request=request,
        name="modules/hr_payroll/employees/employee_list.html",
        context={
            "current_user": current_user,
            "employees": employees,
            "businesses": businesses,
            "departments": departments,
            "job_titles": job_titles,
            "biz_map": biz_map,
            "dept_map": dept_map,
            "jt_map": jt_map,
            "total_count": total_count,
            "active_count": active_count,
            "inactive_count": inactive_count,
            "dept_head_count": dept_head_count,
            "active_page": "employees",
        },
    )


@router.get("/employees/create2", response_class=HTMLResponse)
async def employee_create2_page(
    request: Request,
    db: Session = Depends(get_db),
    async_db=Depends(get_async_db),
    current_user: User = Depends(require_permission("hrm", "employees", "create")),
):
    resolved_business_id = resolve_business_id(current_user, None)
    businesses = business_service.list_businesses(db, skip=0, limit=500)
    departments = department_service.get_departments(db, skip=0, limit=500, business_id=resolved_business_id)
    job_titles = job_title_service.get_job_titles(db, skip=0, limit=500, business_id=resolved_business_id)
    employees = employee_service.get_employees(db, skip=0, limit=500, business_id=resolved_business_id)

    if current_user and not current_user.is_superuser:
        businesses = [b for b in businesses if b.id == current_user.business_id]

    active_departments = [d for d in departments if getattr(d, "is_active", True)]
    active_job_titles = [j for j in job_titles if getattr(j, "is_active", True)]

    return templates.TemplateResponse(
        request=request,
        name="modules/hr_payroll/employees/employee_form2.html",
        context={
            "current_user": current_user,
            "employee": None,
            "is_edit": False,
            "businesses": businesses,
            "departments": active_departments,
            "job_titles": active_job_titles,
            "all_employees": employees,
            "gender_options": [e.value for e in GenderEnum],
            "marital_status_options": [e.value for e in MaritalStatusEnum],
            "work_arrangement_options": [e.value for e in WorkArrangementEnum],
            "employment_type_options": [e.value for e in EmploymentTypeEnum],
            "active_page": "employees2",
        },
    )


@router.get("/employees/create", response_class=HTMLResponse)
async def employee_create_page(
    request: Request,
    db: Session = Depends(get_db),
    async_db=Depends(get_async_db),
    current_user: User = Depends(require_permission("hrm", "employees", "create")),
):
    resolved_business_id = resolve_business_id(current_user, None)
    businesses = business_service.list_businesses(db, skip=0, limit=500)
    departments = department_service.get_departments(db, skip=0, limit=500, business_id=resolved_business_id)
    job_titles = job_title_service.get_job_titles(db, skip=0, limit=500, business_id=resolved_business_id)
    employees = employee_service.get_employees(db, skip=0, limit=500, business_id=resolved_business_id)

    if current_user and not current_user.is_superuser:
        businesses = [b for b in businesses if b.id == current_user.business_id]

    active_departments = [d for d in departments if getattr(d, "is_active", True)]
    active_job_titles = [j for j in job_titles if getattr(j, "is_active", True)]

    return templates.TemplateResponse(
        request=request,
        name="modules/hr_payroll/employees/employee_form2.html",
        context={
            "current_user": current_user,
            "employee": None,
            "is_edit": False,
            "businesses": businesses,
            "departments": active_departments,
            "job_titles": active_job_titles,
            "all_employees": employees,
            "gender_options": [e.value for e in GenderEnum],
            "marital_status_options": [e.value for e in MaritalStatusEnum],
            "work_arrangement_options": [e.value for e in WorkArrangementEnum],
            "employment_type_options": [e.value for e in EmploymentTypeEnum],
            "active_page": "employees",
        },
    )


@router.get("/employees/detail/{employee_id}", response_class=HTMLResponse)
async def employee_detail_page(
    employee_id: uuid.UUID,
    request: Request,
    db: Session = Depends(get_db),
    async_db=Depends(get_async_db),
    current_user: User = Depends(require_permission("hrm", "employees", "view")),
):
    employee = employee_service.get_employee(db, employee_id, current_user=current_user)
    business = None
    if employee.business_id:
        try:
            business = business_service.get_business(db, employee.business_id)
        except Exception:
            business = None

    return templates.TemplateResponse(
        request=request,
        name="modules/hr_payroll/employees/employee_detail.html",
        context={
            "current_user": current_user,
            "employee": employee,
            "business": business,
            "active_page": "employees",
        },
    )


@router.get("/employees/edit/{employee_id}", response_class=HTMLResponse)
async def employee_edit_page(
    employee_id: uuid.UUID,
    request: Request,
    db: Session = Depends(get_db),
    async_db=Depends(get_async_db),
    current_user: User = Depends(require_permission("hrm", "employees", "update")),
):
    employee = employee_service.get_employee(db, employee_id, current_user=current_user)
    resolved_business_id = resolve_business_id(current_user, employee.business_id)
    businesses = business_service.list_businesses(db, skip=0, limit=500)
    departments = department_service.get_departments(db, skip=0, limit=500, business_id=resolved_business_id)
    job_titles = job_title_service.get_job_titles(db, skip=0, limit=500, business_id=resolved_business_id)
    employees = employee_service.get_employees(db, skip=0, limit=500, business_id=resolved_business_id)

    if current_user and not current_user.is_superuser:
        businesses = [b for b in businesses if b.id == current_user.business_id]

    active_departments = [
        d for d in departments if getattr(d, "is_active", True) or (employee and d.id == employee.department_id)
    ]
    active_job_titles = [
        j for j in job_titles if getattr(j, "is_active", True) or (employee and j.id == employee.job_title_id)
    ]

    # Exclude current employee from manager choices to avoid self-selection
    other_employees = [e for e in employees if e.id != employee_id]

    return templates.TemplateResponse(
        request=request,
        name="modules/hr_payroll/employees/employee_form2.html",
        context={
            "current_user": current_user,
            "employee": employee,
            "is_edit": True,
            "businesses": businesses,
            "departments": active_departments,
            "job_titles": active_job_titles,
            "all_employees": other_employees,
            "gender_options": [e.value for e in GenderEnum],
            "marital_status_options": [e.value for e in MaritalStatusEnum],
            "work_arrangement_options": [e.value for e in WorkArrangementEnum],
            "employment_type_options": [e.value for e in EmploymentTypeEnum],
            "active_page": "employees",
        },
    )
