import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

from app.modules.ecommerce.orders.models import (
    OrderFulfillmentStatus,
    OrderPaymentStatus,
)


class OrderItemCreate(BaseModel):
    variant_id: uuid.UUID
    quantity: int = Field(..., gt=0)


class OrderAddressCreate(BaseModel):
    address_type: str = Field("shipping", max_length=50)
    recipient_name: str = Field(..., max_length=255)
    phone: str | None = Field(None, max_length=50)
    street: str = Field(..., max_length=255)
    city: str = Field(..., max_length=100)
    state: str | None = Field(None, max_length=100)
    zip_code: str | None = Field(None, max_length=20)
    country: str = Field(..., max_length=100)


class OrderCreate(BaseModel):
    business_id: int = Field(1)
    user_id: uuid.UUID
    guest_email: str | None = Field(None, max_length=255)
    items: list[OrderItemCreate] = Field(..., min_length=1)
    shipping_address: OrderAddressCreate
    billing_address: OrderAddressCreate | None = None
    currency: str = Field("USD", max_length=3)
    shipping_amount: float = Field(0.0)
    tax_amount: float = Field(0.0)
    discount_amount: float = Field(0.0)
    other_charges: float = Field(0.0)
    customer_note: str | None = None
    payment_method: str | None = Field(None, max_length=50)
    payment_channel: str | None = Field(None, max_length=50)
    delivery_method: str | None = Field(None, max_length=50)
    courier_company: str | None = Field(None, max_length=50)
    tracking_id: str | None = Field(None, max_length=100)


class OrderItemOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    order_id: uuid.UUID
    variant_id: uuid.UUID
    seller_id: uuid.UUID | None = None
    quantity: int
    unit_price: float
    subtotal: float


class OrderAddressOut(OrderAddressCreate):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    order_id: uuid.UUID


class OrderStatusHistoryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    status_type: str
    status_value: str
    note: str | None = None
    created_at: datetime


class OrderStatusUpdate(BaseModel):
    payment_status: OrderPaymentStatus | None = None
    fulfillment_status: OrderFulfillmentStatus | None = None
    note: str | None = None


class OrderUpdate(BaseModel):
    business_id: int | None = None
    user_id: uuid.UUID | None = None
    currency: str | None = Field(None, max_length=3)
    payment_status: OrderPaymentStatus | None = None
    fulfillment_status: OrderFulfillmentStatus | None = None
    items: list[OrderItemCreate] | None = None
    shipping_address: OrderAddressCreate | None = None
    billing_address: OrderAddressCreate | None = None
    shipping_amount: float | None = None
    tax_amount: float | None = None
    discount_amount: float | None = None
    other_charges: float | None = None
    customer_note: str | None = None
    payment_method: str | None = Field(None, max_length=50)
    payment_channel: str | None = Field(None, max_length=50)
    delivery_method: str | None = Field(None, max_length=50)
    courier_company: str | None = Field(None, max_length=50)
    tracking_id: str | None = Field(None, max_length=100)
    note: str | None = None


class OrderSummary(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    business_id: int
    order_number: str
    user_id: uuid.UUID | None = None
    payment_status: OrderPaymentStatus
    fulfillment_status: OrderFulfillmentStatus
    subtotal_amount: float = 0.0
    tax_amount: float = 0.0
    shipping_amount: float = 0.0
    discount_amount: float = 0.0
    other_charges: float = 0.0
    total_amount: float
    currency: str
    payment_method: str | None = None
    payment_channel: str | None = None
    delivery_method: str | None = None
    courier_company: str | None = None
    tracking_id: str | None = None
    created_at: datetime


class OrderDetail(OrderSummary):
    items: list[OrderItemOut] = []
    addresses: list[OrderAddressOut] = []
    status_history: list[OrderStatusHistoryOut] = []