import uuid
from decimal import Decimal

from sqlalchemy.orm import Session

from app.modules.ecommerce.orders.models import (
    Order,
    OrderAddress,
    OrderFulfillmentStatus,
    OrderItem,
    OrderPaymentStatus,
    OrderStatusHistory,
    OrderStatusType,
)
from app.modules.ecommerce.orders.schemas import (
    OrderCreate,
    OrderStatusUpdate,
    OrderUpdate,
)


class OrderRepository:
    def create_order(
        self,
        db: Session,
        data: OrderCreate,
        calculated_total: Decimal,
        items_with_prices: list[
            tuple[
                uuid.UUID,
                uuid.UUID | None,
                str,
                str,
                dict | None,
                int,
                Decimal,
                Decimal,
            ]
        ],
    ) -> Order:
        order_num = f"ORD-{uuid.uuid4().hex[:8].upper()}"
        shipping = Decimal(str(data.shipping_amount))
        tax = Decimal(str(data.tax_amount))
        discount = Decimal(str(data.discount_amount))
        other_charges = Decimal(str(data.other_charges or 0.0))
        total = max(
            Decimal("0.00"),
            calculated_total + shipping + tax + other_charges - discount,
        )

        order = Order(
            business_id=data.business_id,
            user_id=data.user_id,
            guest_email=data.guest_email,
            order_number=order_num,
            payment_status=OrderPaymentStatus.UNPAID,
            fulfillment_status=OrderFulfillmentStatus.PENDING,
            subtotal_amount=calculated_total,
            shipping_amount=shipping,
            tax_amount=tax,
            discount_amount=discount,
            other_charges=other_charges,
            total_amount=total,
            currency=data.currency,
            customer_note=data.customer_note,
            payment_method=data.payment_method,
            payment_channel=data.payment_channel,
            delivery_method=data.delivery_method,
            courier_company=data.courier_company,
            tracking_id=data.tracking_id,
        )
        db.add(order)
        db.flush()

        # Add Order Items
        for (
            variant_id,
            seller_id,
            title,
            sku,
            attrs,
            qty,
            unit_price,
            subtotal,
        ) in items_with_prices:
            item = OrderItem(
                order_id=order.id,
                variant_id=variant_id,
                seller_id=seller_id,
                product_title=title,
                product_sku=sku,
                variant_attributes=attrs,
                quantity=qty,
                unit_price=unit_price,
                subtotal=subtotal,
            )
            db.add(item)

        # Add Status History
        history = OrderStatusHistory(
            order_id=order.id,
            status_type=OrderStatusType.FULFILLMENT,
            status_value=OrderFulfillmentStatus.PENDING,
            note="Order placed.",
        )
        db.add(history)

        # Add Shipping Address
        ship_data = data.shipping_address.model_dump()
        ship_data.pop("address_type", None)
        ship_addr = OrderAddress(
            order_id=order.id,
            address_type="shipping",
            **ship_data,
        )
        db.add(ship_addr)

        if data.billing_address:
            bill_data = data.billing_address.model_dump()
            bill_data.pop("address_type", None)
            bill_addr = OrderAddress(
                order_id=order.id,
                address_type="billing",
                **bill_data,
            )
            db.add(bill_addr)

        db.commit()
        db.refresh(order)
        return order

    def update_order(
        self,
        db: Session,
        order: Order,
        data: OrderUpdate,
        calculated_total: Decimal | None = None,
        items_with_prices: list[
            tuple[
                uuid.UUID,
                uuid.UUID | None,
                str,
                str,
                dict | None,
                int,
                Decimal,
                Decimal,
            ]
        ]
        | None = None,
    ) -> Order:
        if data.business_id is not None:
            order.business_id = data.business_id
        if data.user_id is not None:
            order.user_id = data.user_id
        if data.currency is not None:
            order.currency = data.currency
        if data.shipping_amount is not None:
            order.shipping_amount = Decimal(str(data.shipping_amount))
        if data.tax_amount is not None:
            order.tax_amount = Decimal(str(data.tax_amount))
        if data.discount_amount is not None:
            order.discount_amount = Decimal(str(data.discount_amount))
        if data.other_charges is not None:
            order.other_charges = Decimal(str(data.other_charges))
        if data.customer_note is not None:
            order.customer_note = data.customer_note
        if data.payment_method is not None:
            order.payment_method = data.payment_method
        if data.payment_channel is not None:
            order.payment_channel = data.payment_channel
        if data.delivery_method is not None:
            order.delivery_method = data.delivery_method
        if data.courier_company is not None:
            order.courier_company = data.courier_company
        if data.tracking_id is not None:
            order.tracking_id = data.tracking_id
        if data.payment_status is not None and data.payment_status != order.payment_status:
            order.payment_status = data.payment_status
            history = OrderStatusHistory(
                order_id=order.id,
                status_type=OrderStatusType.PAYMENT,
                status_value=data.payment_status,
                note=data.note or "Payment status updated during order edit.",
            )
            db.add(history)
        if data.fulfillment_status is not None and data.fulfillment_status != order.fulfillment_status:
            order.fulfillment_status = data.fulfillment_status
            history = OrderStatusHistory(
                order_id=order.id,
                status_type=OrderStatusType.FULFILLMENT,
                status_value=data.fulfillment_status,
                note=data.note or "Fulfillment status updated during order edit.",
            )
            db.add(history)

        if items_with_prices is not None and calculated_total is not None:
            db.query(OrderItem).filter(OrderItem.order_id == order.id).delete()
            order.subtotal_amount = calculated_total

            for (
                variant_id,
                seller_id,
                title,
                sku,
                attrs,
                qty,
                unit_price,
                subtotal,
            ) in items_with_prices:
                item = OrderItem(
                    order_id=order.id,
                    variant_id=variant_id,
                    seller_id=seller_id,
                    product_title=title,
                    product_sku=sku,
                    variant_attributes=attrs,
                    quantity=qty,
                    unit_price=unit_price,
                    subtotal=subtotal,
                )
                db.add(item)

        order.total_amount = max(
            Decimal("0.00"),
            order.subtotal_amount + order.shipping_amount + order.tax_amount + order.other_charges - order.discount_amount
        )

        if data.shipping_address:
            db.query(OrderAddress).filter(
                OrderAddress.order_id == order.id, OrderAddress.address_type == "shipping"
            ).delete()
            ship_data = data.shipping_address.model_dump()
            ship_data.pop("address_type", None)
            ship_addr = OrderAddress(
                order_id=order.id,
                address_type="shipping",
                **ship_data,
            )
            db.add(ship_addr)

        if data.billing_address:
            db.query(OrderAddress).filter(
                OrderAddress.order_id == order.id, OrderAddress.address_type == "billing"
            ).delete()
            bill_data = data.billing_address.model_dump()
            bill_data.pop("address_type", None)
            bill_addr = OrderAddress(
                order_id=order.id,
                address_type="billing",
                **bill_data,
            )
            db.add(bill_addr)

        db.commit()
        db.refresh(order)
        return order

    def delete_order(self, db: Session, order: Order) -> None:
        db.delete(order)
        db.commit()

    def get_order_by_id(
        self, db: Session, order_id: uuid.UUID, business_id: int | None = None
    ) -> Order | None:
        query = db.query(Order).filter(Order.id == order_id)
        if business_id is not None:
            query = query.filter(Order.business_id == business_id)
        return query.first()

    def get_orders(
        self,
        db: Session,
        business_id: int | None = None,
        user_id: uuid.UUID | None = None,
        payment_status: OrderPaymentStatus | None = None,
        fulfillment_status: OrderFulfillmentStatus | None = None,
        skip: int = 0,
        limit: int = 100,
    ) -> list[Order]:
        query = db.query(Order)
        if business_id is not None:
            query = query.filter(Order.business_id == business_id)
        if user_id:
            query = query.filter(Order.user_id == user_id)
        if payment_status:
            query = query.filter(Order.payment_status == payment_status)
        if fulfillment_status:
            query = query.filter(Order.fulfillment_status == fulfillment_status)
        return query.order_by(Order.created_at.desc()).offset(skip).limit(limit).all()

    def update_order_status(
        self, db: Session, order: Order, update_data: OrderStatusUpdate
    ) -> Order:
        if update_data.payment_status:
            order.payment_status = update_data.payment_status
            history = OrderStatusHistory(
                order_id=order.id,
                status_type=OrderStatusType.PAYMENT,
                status_value=update_data.payment_status,
                note=update_data.note,
            )
            db.add(history)
        if update_data.fulfillment_status:
            order.fulfillment_status = update_data.fulfillment_status
            history = OrderStatusHistory(
                order_id=order.id,
                status_type=OrderStatusType.FULFILLMENT,
                status_value=update_data.fulfillment_status,
                note=update_data.note,
            )
            db.add(history)
        db.commit()
        db.refresh(order)
        return order
