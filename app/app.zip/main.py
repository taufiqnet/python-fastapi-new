import logging
import os

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from fastapi.templating import Jinja2Templates

from app.core.config import settings
from app.core.deps import get_current_user_optional
from app.core.identity.seed import seed_system_admin_and_permissions, seed_system_admin_and_permissions_sync
from app.database import AsyncSessionLocal, Base, SessionLocal, async_engine, engine

from app.core.billing.feature_config import resolve_menu_for_user

# Ensure template responses automatically receive request.state.user as current_user & nav_menu
_original_template_response = Jinja2Templates.TemplateResponse


def _custom_template_response(self, *args, **kwargs):
    name = kwargs.get("name")
    if not name and args:
        if isinstance(args[0], str):
            name = args[0]
        elif len(args) > 1 and isinstance(args[1], str):
            name = args[1]

    context = kwargs.get("context")
    if not context:
        for arg in args:
            if isinstance(arg, dict):
                context = arg
                break
    if context is None:
        context = {}

    request = kwargs.get("request")
    if not request:
        if args and hasattr(args[0], "state"):
            request = args[0]
        elif isinstance(context, dict) and "request" in context:
            request = context["request"]

    if request and isinstance(context, dict):
        if "request" not in context:
            context["request"] = request
        user = getattr(request.state, "user", None)
        if "current_user" not in context and user:
            context["current_user"] = user

        current_user = context.get("current_user") or user
        if "nav_menu" not in context:
            context["nav_menu"] = resolve_menu_for_user(current_user)

        if "settings" not in context:
            context["settings"] = settings

    if request and name:
        new_kwargs = {k: v for k, v in kwargs.items() if k not in ("request", "name", "context")}
        try:
            return _original_template_response(self, request=request, name=name, context=context, **new_kwargs)
        except TypeError:
            return _original_template_response(self, name, context, **new_kwargs)

    return _original_template_response(self, *args, **kwargs)


Jinja2Templates.TemplateResponse = _custom_template_response

# Registers every module's models with Base.metadata in one place
from app import models_registry  # noqa: F401

# Routers
from app.modules.ecommerce.brands.router import router as brands_router
from app.modules.ecommerce.cart.router import router as cart_router
from app.modules.ecommerce.categories.router import router as categories_router
from app.modules.ecommerce.customer.router import router as customers_router
from app.modules.ecommerce.inventory.router import router as inventory_router
from app.modules.ecommerce.notifications.router import router as notifications_router
from app.modules.ecommerce.orders.router import router as orders_router
from app.modules.ecommerce.payments.router import router as payments_router
from app.modules.ecommerce.pricing.router import router as pricing_router
from app.modules.ecommerce.products.router import router as products_router
from app.modules.ecommerce.reviews.router import router as reviews_router
from app.modules.ecommerce.search.router import router as search_router
from app.modules.ecommerce.sellers.router import router as sellers_router
from app.modules.ecommerce.shipping.router import router as shipping_router
from app.modules.ecommerce.reports.router import router as reports_router
from app.modules.finance.router import router as finance_router
from app.modules.hr_payroll.organization.router import (
    router as organization_router,
)
from app.modules.hr_payroll.employees.router import router as employees_router
from app.modules.hr_payroll.leave.router import router as leave_router
from app.modules.hr_payroll.attendance.router import router as attendance_router
from app.modules.hr_payroll.compensation.router import router as compensation_router
from app.modules.hr_payroll.payroll.router import router as payroll_router
from app.modules.hr_payroll.certificates.router import router as certificates_router
from app.modules.hr_payroll.offer_letters.router import router as offer_letters_router
from app.modules.hr_payroll.experience_letters.router import router as experience_letters_router
from app.modules.hr_payroll.appointments.router import router as appointments_router
from app.modules.hr_payroll.notice_board.router import router as notices_router
from app.modules.hr_payroll.recruitment.router import router as recruitment_router
from app.api.v1.endpoints.sync import router as sync_router

from app.routers import (
    ai_chat,
    appointment_views,
    attendance_views,
    auth,
    report_views,
    brand_views,
    business,
    business_views,
    catalog_views,
    category_views,
    certificate_views,
    compensation_views,
    experience_letter_views,
    customer_views,
    employee_views,
    finance_views,
    inventory_views,
    leave_views,
    model_views,
    notice_views,
    notification_views,
    offer_letter_views,
    order_views,
    organization_views,
    payment_views,
    payroll_views,
    pricing_views,
    product_views,
    recruitment_views,
    review_views,
    role_views,
    seller_views,
    shipping_views,
    subscription_plan_views,
    user_views,
    mcp_views,
    tasks,
)

logger = logging.getLogger(__name__)

if settings.app_env in ("development", "test", "local"):
    try:
        Base.metadata.create_all(bind=engine)
        db = SessionLocal()
        try:
            seed_system_admin_and_permissions_sync(db)
        finally:
            db.close()
    except Exception:
        logger.exception("Failed to create database tables on startup")
        raise

app = FastAPI(
    title="E-Commerce API",
    version="1.0.0",
)

templates = Jinja2Templates(directory="app/templates")


from starlette.exceptions import HTTPException as StarletteHTTPException


@app.exception_handler(HTTPException)
@app.exception_handler(StarletteHTTPException)
async def custom_http_exception_handler(request: Request, exc: HTTPException | StarletteHTTPException):
    accept = request.headers.get("accept", "")
    is_html = "text/html" in accept and not (request.url.path.startswith("/api") or request.url.path.endswith("/api"))

    if is_html:
        if exc.status_code == 403:
            return templates.TemplateResponse(
                request=request,
                name="errors/403.html",
                context={
                    "detail": exc.detail,
                    "current_user": getattr(request.state, "user", None),
                },
                status_code=403,
            )
        elif exc.status_code == 404:
            return templates.TemplateResponse(
                request=request,
                name="errors/404.html",
                context={
                    "detail": exc.detail,
                    "current_user": getattr(request.state, "user", None),
                },
                status_code=404,
            )
        elif exc.status_code >= 500:
            return templates.TemplateResponse(
                request=request,
                name="errors/500.html",
                context={
                    "detail": exc.detail,
                    "current_user": getattr(request.state, "user", None),
                },
                status_code=exc.status_code,
            )

    from fastapi.responses import JSONResponse
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})


@app.exception_handler(Exception)
async def custom_general_exception_handler(request: Request, exc: Exception):
    logger.exception(f"Unhandled exception on path {request.url.path}: {exc}")
    accept = request.headers.get("accept", "")
    is_html = "text/html" in accept and not (request.url.path.startswith("/api") or request.url.path.endswith("/api"))

    if is_html:
        return templates.TemplateResponse(
            request=request,
            name="errors/500.html",
            context={
                "detail": "An internal server error occurred.",
                "current_user": getattr(request.state, "user", None),
            },
            status_code=500,
        )

    from fastapi.responses import JSONResponse
    return JSONResponse(status_code=500, content={"detail": "Internal Server Error"})


@app.on_event("startup")
async def on_startup():
    try:
        async with async_engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        async with AsyncSessionLocal() as db:
            await seed_system_admin_and_permissions(db)

        # Mark any interrupted import jobs from previous server restarts
        try:
            db_sync = SessionLocal()
            try:
                from app.modules.hr_payroll.employees.models import ImportJob
                interrupted_jobs = db_sync.query(ImportJob).filter(ImportJob.status == "processing").all()
                for ij in interrupted_jobs:
                    ij.status = "interrupted"
                if interrupted_jobs:
                    db_sync.commit()
            finally:
                db_sync.close()
        except Exception:
            logger.exception("Failed to mark interrupted import jobs")
    except Exception:
        logger.exception("Failed async startup table creation or seeding")


@app.middleware("http")
async def auth_and_cache_middleware(request: Request, call_next):
    path = request.url.path

    # Exempt public/API/static routes from HTML auth redirect
    is_public = (
        path.startswith("/auth")
        or path.startswith("/static")
        or path.startswith("/health")
        or "/api/" in path
        or path.endswith("/api")
        or request.headers.get("accept", "").find("text/html") == -1
    )

    override = app.dependency_overrides.get(get_current_user_optional)
    if override:
        import inspect

        if inspect.iscoroutinefunction(override):
            current_user = await override(request)
        else:
            current_user = override(request)
    else:
        async with AsyncSessionLocal() as db:
            current_user = await get_current_user_optional(request, None, db)

    if current_user and current_user.is_active:
        request.state.user = current_user
    elif not is_public and path != "/":
        redirect_res = RedirectResponse(url="/auth/login", status_code=302)
        redirect_res.headers["Cache-Control"] = (
            "no-cache, no-store, must-revalidate, max-age=0"
        )
        redirect_res.headers["Pragma"] = "no-cache"
        redirect_res.headers["Expires"] = "0"
        return redirect_res

    response = await call_next(request)

    # Set no-cache headers on HTML responses to prevent stale pages when pressing browser Back button
    content_type = response.headers.get("content-type", "")
    if "text/html" in content_type:
        response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"

    return response


os.makedirs("app/static/ecommerce/images", exist_ok=True)
os.makedirs("app/static/uploads/logos", exist_ok=True)
app.mount("/static", StaticFiles(directory="app/static"), name="static")

app.add_middleware(
    CORSMiddleware,
    allow_origins=getattr(settings, "cors_origins", ["*"]),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(ai_chat.router)
app.include_router(business_views.router)
app.include_router(category_views.router)
app.include_router(customer_views.router)
app.include_router(brand_views.router)
app.include_router(model_views.router)
app.include_router(product_views.router)
app.include_router(pricing_views.router)
app.include_router(payment_views.router)
app.include_router(shipping_views.router)
app.include_router(review_views.router)
app.include_router(seller_views.router)
app.include_router(report_views.router)
app.include_router(finance_views.router)
app.include_router(catalog_views.router)
app.include_router(order_views.router)
app.include_router(inventory_views.router)
app.include_router(organization_views.router)
app.include_router(employee_views.router)
app.include_router(leave_views.router)
app.include_router(attendance_views.router)
app.include_router(compensation_views.router)
app.include_router(payroll_views.router)
app.include_router(certificate_views.router)
app.include_router(offer_letter_views.router)
app.include_router(experience_letter_views.router)
app.include_router(appointment_views.router)
app.include_router(notice_views.router)
app.include_router(recruitment_views.router)
app.include_router(role_views.router)
app.include_router(subscription_plan_views.router)
app.include_router(user_views.router)
app.include_router(mcp_views.router)
app.include_router(business.router)

# ecommerce module router
app.include_router(brands_router)
app.include_router(categories_router)
app.include_router(customers_router)
app.include_router(products_router)
app.include_router(inventory_router)
app.include_router(pricing_router)
app.include_router(cart_router)
app.include_router(notification_views.router)
app.include_router(orders_router)
app.include_router(payments_router)
app.include_router(shipping_router)
app.include_router(reviews_router)
app.include_router(sellers_router)
app.include_router(notifications_router)
app.include_router(search_router)
app.include_router(reports_router)
app.include_router(finance_router)

# hr payroll router
app.include_router(organization_router)
app.include_router(employees_router)
app.include_router(leave_router)
app.include_router(attendance_router)
app.include_router(compensation_router)
app.include_router(payroll_router)
app.include_router(certificates_router)
app.include_router(offer_letters_router)
app.include_router(experience_letters_router)
app.include_router(appointments_router)
app.include_router(notices_router)
app.include_router(recruitment_router)

# project management router
app.include_router(tasks.router)
app.include_router(sync_router)


from fastapi.responses import FileResponse


@app.get("/sw.js")
def get_service_worker():
    sw_path = "app/static/sw.js"
    if not os.path.exists(sw_path):
        return HTMLResponse(content="// Service worker placeholder", media_type="application/javascript")
    return FileResponse(sw_path, media_type="application/javascript")


@app.get("/health")
def health_check():
    return {
        "status": "healthy",
        "environment": settings.app_env,
    }
